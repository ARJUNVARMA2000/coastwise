# Method A defect extraction

Native PDF text → bounded chunks → one extraction-and-grade request per chunk → local checks.
No OCR, image interpretation or specialized layout reading is performed. Scans, drawn marks,
image-only scales and unreliable reading order can omit findings. See manifest.csv and review.csv
for coverage and limitations. Missing findings and uncertain grades never imply sound condition.

The linked tables are an output format. defects.csv retains finding, component/location,
measurements in their original units, original rating/scale, project grade or uncertainty and
a short reason. measurements.csv and citations.csv resolve measurements and supporting
quotations by ID and absolute one-based PDF page. Shared context is stored on component rows.
Numeric project grades require a registered rule and locally checked component/material
evidence. Original report ratings remain separate. Grades are provisional, not engineering review.

CSV, JSON and Excel contain the same records. List/object CSV cells use JSON. Native quote
matching establishes text presence, not completeness or semantic ownership. Larger/dense reports
may take longer than the unmeasured approximately two-minute target for 20–50-page text reports.
